/*
* network.h
*
*      Author: Boross David
*/
#ifndef READER_H_
#define READER_H_

#include <iostream>
#include <vector>

using namespace std;

// Program 1
//int ReverseInt(int i);
//void ReadMNIST(string file_to_read, int NumberOfImages, int DataOfAnImage, vector<vector<double>> &arr);

// Program 2
int file_read_it_now(string);

#endif /* READER_H_ */
